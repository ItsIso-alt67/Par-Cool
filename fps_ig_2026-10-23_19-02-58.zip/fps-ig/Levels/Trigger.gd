extends Area3D

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node3D) -> void:
	# Check if the colliding body is our player controller
	if body is CharacterBody3D:
		GameManager.load_next_level()
