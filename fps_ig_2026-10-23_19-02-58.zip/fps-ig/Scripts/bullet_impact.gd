extends GPUParticles3D

func _ready() -> void:
	emitting = true
	# Self-destruct after emission finishes
	await get_tree().create_timer(lifetime).timeout
	queue_free()
