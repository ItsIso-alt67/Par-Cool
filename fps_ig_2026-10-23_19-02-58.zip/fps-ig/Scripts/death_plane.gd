extends Area3D

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node3D) -> void:
	if body.is_in_group("player") or body.name == "Player":
		# Safe reload deferred to the end of the physics frame
		get_tree().reload_current_scene.call_deferred()
