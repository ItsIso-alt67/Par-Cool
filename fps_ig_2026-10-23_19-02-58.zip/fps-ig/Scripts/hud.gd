extends Control

@onready var health_label: Label = $HealthLabel


func update_health(amount: float) -> void:
	health_label.text = str(int(amount))
