extends Node

# List your level scene file paths in order
var levels: Array[String] = [
	"res://Levels/Level1.tscn",
	"res://Levels/SandBox.tscn"
]
var current_level_index: int = 0

func load_main_menu() -> void:
	current_level_index = 0
	get_tree().change_scene_to_file("res://main_menu.tscn")

func load_level(index: int) -> void:
	current_level_index = index
	if current_level_index < levels.size():
		get_tree().change_scene_to_file(levels[current_level_index])
	else:
		load_main_menu()

func load_next_level() -> void:
	current_level_index += 1
	if current_level_index < levels.size():
		get_tree().change_scene_to_file(levels[current_level_index])
	else:
		# Completed all levels, return to main menu
		load_main_menu()
