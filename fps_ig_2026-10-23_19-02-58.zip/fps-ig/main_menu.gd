extends Control

@onready var main_container: VBoxContainer = $MainButtonContainer
@onready var level_select_container: VBoxContainer = $LevelSelectContainer

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	
	# Show main menu, hide level select by default
	main_container.visible = true
	level_select_container.visible = false

func _on_play_button_pressed() -> void:
	main_container.visible = false
	level_select_container.visible = true

func _on_back_button_pressed() -> void:
	main_container.visible = true
	level_select_container.visible = false

func _on_quit_button_pressed() -> void:
	get_tree().quit()

# Mode / Level Selection
func _on_tutorial_button_pressed() -> void:
	# Assuming Tutorial is index 0 in your GameManager levels array
	GameManager.load_level(0)

func _on_sandbox_button_pressed() -> void:
	# Assuming Sandbox is index 1 in your GameManager levels array
	GameManager.load_level(1)
