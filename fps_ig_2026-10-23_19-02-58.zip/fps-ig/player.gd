extends CharacterBody3D

@export_group("Movement Constants")
@export var walk_speed: float = 14.0
@export var dash_speed: float = 20.0
@export var slide_speed: float = 24.0
@export var jump_velocity: float = 20
@export var slam_speed: float = 75.0
@export var gravity: float = 30.0

@export_group("Parkour Mechanics")
@export var double_jump_velocity: float = 15.0
@export var wall_slide_gravity: float = 8.0
@export var wall_run_speed: float = 12.5
@export var wall_climb_speed: float = 30.0
@export var roll_boost_speed: float = 36.0
@export var roll_window_threshold: float = -18.0
@export var roll_duration: float = 0.4
@export var roll_speed_multiplier: float = 2.5
@export var air_friction: float = 30.0

@export_group("Dash Settings")
@export var dash_duration: float = 0.9
@export var dash_cooldown: float = 0.5

@export_group("Slam Settings")
@export var slam_jump_multiplier: float = 1.8

@export_group("Jump Speed Scaling Settings")
@export var speed_jump_scaling: float = 0.002  # Extra jump height scaling factor per unit of speed
@export var max_speed_jump_multiplier: float = 999999999999999999 # Maximum multiplier cap for speed-boosted jumps

@export_group("Wall Jump Settings")
@export var wall_jump_launch_speed: float = 20.0
@export var wall_jump_up_force: float = 22.0
@export var wall_jump_coyote_time: float = 1.0
@export var wall_jump_cooldown: float = 0.0

@export_group("Look Settings")
@export var mouse_sensitivity: float = 0.0025
@export var controller_sensitivity: float = 3.0

@export_group("Camera Effects")
@export var base_fov: float = 75.0
@export var max_fov: float = 120.0
@export var fov_change_speed: float = 12.0
@export var max_tilt_angle: float = 3.5
@export var wall_run_tilt_angle: float = 15.0
@export var tilt_speed: float = 22.0
@export var slide_camera_offset: float = -0.8
@export var height_change_speed: float = 16.0
@export var climb_shake_intensity: float = 0.035 # Magnitude of the camera jerk
@export var climb_shake_speed: float = 28.0      # Speed/frequency of hand movements

@onready var pivot: Node3D = $CameraPivot
@onready var camera: Camera3D = $CameraPivot/Camera3D
@onready var collider: CollisionShape3D = $CollisionShape3D

# Look Rotations
var camera_rot_x: float = 0.0
var camera_rot_y: float = 0.0
@onready var default_camera_y: float = pivot.position.y if pivot else 0.0
var current_camera_y: float = 0.0
var camera_kick: float = 0.0
var climb_shake_timer: float = 0.0

# Movement State
var is_sliding: bool = false
var is_slamming: bool = false
var is_rolling: bool = false
var is_wall_running: bool = false
var is_wall_sliding: bool = false
var is_wall_climbing: bool = false
var is_wall_clinging: bool = false

var slide_vector: Vector3 = Vector3.ZERO
var current_roll_speed: float = 0.0
var stored_slam_boost: bool = false
var can_double_jump: bool = false

# Wall Run & Buffer State
var current_wall_normal: Vector3 = Vector3.ZERO
var wall_run_dir: Vector3 = Vector3.ZERO
var wall_jump_timer: float = 0.0
var wall_jump_cooldown_timer: float = 0.0
var wall_detach_timer: float = 0.0

# Fall & Roll State
var highest_fall_velocity: float = 0.0

# Dash & Roll Timers
var dash_timer: float = 0.0
var dash_cooldown_timer: float = 0.0
var roll_timer: float = 0.0

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

	if collider and collider.shape:
		collider.shape = collider.shape.duplicate()

	if camera:
		camera_rot_y = global_rotation.y
		camera_rot_x = camera.rotation.x
		current_camera_y = default_camera_y

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		camera_rot_y -= event.relative.x * mouse_sensitivity
		camera_rot_x -= event.relative.y * mouse_sensitivity
		camera_rot_x = clamp(camera_rot_x, deg_to_rad(-89.0), deg_to_rad(89.0))
		
		if camera:
			camera.rotation.x = camera_rot_x

func _process(delta: float) -> void:
	if pivot:
		pivot.rotation.y = camera_rot_y - global_rotation.y
	update_camera_effects(delta)

func _physics_process(delta: float) -> void:
	global_rotation.y = camera_rot_y

	# Controller Look Input
	var look_dir = Input.get_vector("look_left", "look_right", "look_up", "look_down")
	if look_dir != Vector2.ZERO:
		camera_rot_y -= look_dir.x * controller_sensitivity * delta
		camera_rot_x -= look_dir.y * controller_sensitivity * delta
		camera_rot_x = clamp(camera_rot_x, deg_to_rad(-89.0), deg_to_rad(89.0))
		if camera:
			camera.rotation.x = camera_rot_x

	# Timers
	if dash_timer > 0.0: dash_timer -= delta
	if dash_cooldown_timer > 0.0: dash_cooldown_timer -= delta
	if wall_jump_timer > 0.0: wall_jump_timer -= delta
	if wall_jump_cooldown_timer > 0.0: wall_jump_cooldown_timer -= delta
	if wall_detach_timer > 0.0: wall_detach_timer -= delta
	if roll_timer > 0.0:
		roll_timer -= delta
		if roll_timer <= 0.0:
			is_rolling = false

	if not is_on_floor():
		if velocity.y < highest_fall_velocity:
			highest_fall_velocity = velocity.y

	# --- 1. Detect Walls ---
	var near_wall = is_on_wall_custom()
	if near_wall and wall_jump_cooldown_timer <= 0.0 and wall_detach_timer <= 0.0:
		current_wall_normal = get_wall_normal_custom()
		wall_jump_timer = wall_jump_coyote_time

	# --- 2. Wall Interaction Logic (Climb, Cling, Slide, Run) ---
	var input_dir = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var roll_held = Input.is_action_pressed("roll")

	is_wall_climbing = false
	is_wall_clinging = false
	is_wall_sliding = false
	is_wall_running = false

	if not is_on_floor() and near_wall and wall_jump_cooldown_timer <= 0.0 and wall_detach_timer <= 0.0:
		if roll_held:
			if input_dir.y < -0.1: # Forward -> Climb
				is_wall_climbing = true
			elif input_dir.y > 0.1: # Backward -> Controlled Slide Down
				is_wall_sliding = true
			else: # No Vertical Movement Input -> Wall Cling (Stationary)
				is_wall_clinging = true
		elif input_dir.y < -0.1: # Forward without Roll -> Wall Run
			var forward = -transform.basis.z.normalized()
			wall_run_dir = forward.slide(current_wall_normal).normalized()
			is_wall_running = true

	# --- 3. Gravity & Vertical Movement ---
	if not is_on_floor():
		if is_slamming:
			velocity.y = -slam_speed
		elif is_wall_climbing:
			velocity.y = wall_climb_speed
		elif is_wall_clinging:
			velocity.y = 0.0 # Freeze vertical drop
		elif is_wall_running:
			velocity.y = 0.0
		elif is_wall_sliding:
			velocity.y = move_toward(velocity.y, -wall_slide_gravity, gravity * delta)
		else:
			velocity.y -= gravity * delta
	else:
		can_double_jump = true
		if is_slamming:
			is_slamming = false
			stored_slam_boost = true

	# --- 4. Jump Handling ---
	if Input.is_action_just_pressed("jump"):
		if is_on_floor():
			var current_h_speed = Vector2(velocity.x, velocity.z).length()
			
			# Speed multiplier scaling
			var speed_boost_factor = 1.0 + (current_h_speed * speed_jump_scaling)
			speed_boost_factor = clamp(speed_boost_factor, 1.0, max_speed_jump_multiplier)
			
			var final_jump = jump_velocity * speed_boost_factor
			
			if stored_slam_boost:
				final_jump *= slam_jump_multiplier
				stored_slam_boost = false
				
			velocity.y = final_jump
			
			if is_sliding or is_rolling:
				var boost = current_roll_speed if is_rolling else slide_speed
				var launch_speed = max(current_h_speed, boost)
				velocity.x = slide_vector.x * launch_speed
				velocity.z = slide_vector.z * launch_speed
				is_sliding = false
				is_rolling = false

		elif wall_jump_timer > 0.0 or is_wall_running or is_wall_sliding or is_wall_climbing or is_wall_clinging:
			var wall_normal = current_wall_normal.normalized()
			var forward_dir = -transform.basis.z.normalized()
			var horizontal_launch = (wall_normal + forward_dir).normalized()
			
			var current_h_speed = Vector2(velocity.x, velocity.z).length()
			var new_speed = max(current_h_speed + wall_jump_launch_speed, wall_jump_launch_speed * 1.2)
			
			velocity.y = wall_jump_up_force
			velocity.x = horizontal_launch.x * new_speed
			velocity.z = horizontal_launch.z * new_speed
			
			camera_kick = deg_to_rad(-5.0)
			wall_jump_timer = 0.0
			wall_jump_cooldown_timer = wall_jump_cooldown
			wall_detach_timer = 0.15
			is_wall_running = false
			is_wall_sliding = false
			is_wall_climbing = false
			is_wall_clinging = false
			can_double_jump = true

		elif can_double_jump:
			velocity.y = double_jump_velocity
			can_double_jump = false
			is_slamming = false

	# --- 5. Dash Impulse ---
	if Input.is_action_just_pressed("dash") and dash_cooldown_timer <= 0.0:
		var dash_input = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
		var dash_dir = (transform.basis * Vector3(dash_input.x, 0, dash_input.y)).normalized()
		if dash_dir == Vector3.ZERO:
			dash_dir = -transform.basis.z
		
		var current_h_speed = Vector2(velocity.x, velocity.z).length()
		var new_speed = current_h_speed + dash_speed
		
		velocity.x = dash_dir.x * new_speed
		velocity.z = dash_dir.z * new_speed
		dash_timer = dash_duration
		dash_cooldown_timer = dash_cooldown
		camera_kick = deg_to_rad(-3.5)

	# --- 6. Ground Roll Trigger ---
	var roll_just_pressed = Input.is_action_just_pressed("roll")
	if roll_just_pressed and not is_rolling and is_on_floor():
		is_rolling = true
		roll_timer = roll_duration
		
		var fwd = -transform.basis.z
		slide_vector = fwd
		
		var current_h_speed = Vector2(velocity.x, velocity.z).length()
		var converted_speed = abs(highest_fall_velocity) * roll_speed_multiplier
		current_roll_speed = max(current_h_speed * 1.15, max(roll_boost_speed, converted_speed))
		
		velocity.x = fwd.x * current_roll_speed
		velocity.z = fwd.z * current_roll_speed

	# --- 7. Slide / Slam ---
	if Input.is_action_just_pressed("slide"):
		if is_on_floor():
			is_sliding = true
			var dir = (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
			slide_vector = dir if dir != Vector3.ZERO else -transform.basis.z
			
			var current_h_speed = Vector2(velocity.x, velocity.z).length()
			current_roll_speed = max(current_h_speed, slide_speed)
		else:
			is_slamming = true

	if is_on_floor():
		highest_fall_velocity = 0.0

	if Input.is_action_just_released("slide"):
		is_sliding = false

	if is_on_floor() and not Input.is_action_pressed("jump") and velocity.length_squared() < 1.0:
		stored_slam_boost = false

	# --- 8. Velocity Application ---
	if is_rolling or is_sliding:
		velocity.x = slide_vector.x * current_roll_speed
		velocity.z = slide_vector.z * current_roll_speed
	elif is_wall_clinging:
		# Completely stationary on wall
		velocity.x = -current_wall_normal.x * 2.0
		velocity.z = -current_wall_normal.z * 2.0
	elif is_wall_climbing or is_wall_sliding:
		# Hug wall surface horizontally while moving vertically
		velocity.x = -current_wall_normal.x * 2.0
		velocity.z = -current_wall_normal.z * 2.0
	elif is_wall_running:
		var current_h_speed = Vector2(velocity.x, velocity.z).length()
		var run_speed = max(current_h_speed, wall_run_speed)
		velocity.x = wall_run_dir.x * run_speed
		velocity.z = wall_run_dir.z * run_speed
		velocity -= current_wall_normal * 3.0
	elif dash_timer <= 0.0 and not is_slamming:
		var direction = (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
		var horizontal_vel = Vector2(velocity.x, velocity.z)
		var speed = horizontal_vel.length()
		
		if not is_on_floor():
			if speed > walk_speed:
				speed = move_toward(speed, walk_speed, air_friction * delta)
				
				if direction != Vector3.ZERO:
					var target_vel = direction * speed
					velocity.x = move_toward(velocity.x, target_vel.x, delta * 35.0)
					velocity.z = move_toward(velocity.z, target_vel.z, delta * 35.0)
					
					var new_h_vel = Vector2(velocity.x, velocity.z).normalized() * speed
					velocity.x = new_h_vel.x
					velocity.z = new_h_vel.y
				else:
					var launch_dir = horizontal_vel.normalized()
					velocity.x = launch_dir.x * speed
					velocity.z = launch_dir.y * speed
			elif direction != Vector3.ZERO:
				velocity.x = direction.x * walk_speed
				velocity.z = direction.z * walk_speed
		else:
			if direction != Vector3.ZERO:
				velocity.x = direction.x * walk_speed
				velocity.z = direction.z * walk_speed
			else:
				velocity.x = move_toward(velocity.x, 0, walk_speed)
				velocity.z = move_toward(velocity.z, 0, walk_speed)

	move_and_slide()

# --- Helpers ---
func is_on_wall_custom() -> bool:
	if is_on_wall(): return true
	for child in get_children():
		if child is RayCast3D and child.is_colliding(): return true
	return false

func get_wall_normal_custom() -> Vector3:
	if is_on_wall(): return get_wall_normal()
	for child in get_children():
		if child is RayCast3D and child.is_colliding(): return child.get_collision_normal()
	return transform.basis.z

func update_camera_effects(delta: float) -> void:
	if not camera or not pivot: return

	# Height Offset
	var low_state = is_sliding or is_rolling
	var y_target = default_camera_y + (slide_camera_offset if low_state else 0.0)
	current_camera_y = move_toward(current_camera_y, y_target, height_change_speed * delta)
	
	# Wall Climb Jerk / Shake Offsets
	var climb_offset_x: float = 0.0
	var climb_offset_y: float = 0.0
	
	if is_wall_climbing:
		climb_shake_timer += delta * climb_shake_speed
		climb_offset_x = sin(climb_shake_timer) * climb_shake_intensity
		climb_offset_y = abs(cos(climb_shake_timer * 1.5)) * climb_shake_intensity
	else:
		climb_shake_timer = 0.0

	pivot.position.y = current_camera_y + climb_offset_y
	pivot.position.x = climb_offset_x

	# Pitch Offset & Camera Kick Recovery
	var current_pitch = camera_rot_x + camera_kick
	camera_kick = move_toward(camera_kick, 0.0, delta * 30.0)

	if is_rolling and roll_duration > 0.0:
		var roll_progress = 1.0 - (roll_timer / roll_duration)
		var roll_pitch_offset = sin(roll_progress * PI) * deg_to_rad(14.0)
		current_pitch += roll_pitch_offset

	# Camera Tilt
	var input_x = Input.get_axis("move_left", "move_right")
	var target_tilt = deg_to_rad(-input_x * max_tilt_angle)
	
	if is_wall_running:
		var wall_side_dot = transform.basis.x.dot(current_wall_normal)
		var tilt_dir = -1.0 if wall_side_dot > 0 else 1.0
		target_tilt = deg_to_rad(wall_run_tilt_angle * tilt_dir)

	var tilt_weight = 1.0 - exp(-tilt_speed * delta)
	var current_tilt = lerp_angle(camera.rotation.z, target_tilt, tilt_weight)
	
	camera.rotation = Vector3(current_pitch, 0.0, current_tilt)

	# Responsive FOV Expansion
	var current_speed = Vector2(velocity.x, velocity.z).length()
	var speed_ratio = clamp((current_speed - walk_speed) / 35.0, 0.0, 1.0)
	var target_fov = lerp(base_fov, max_fov, speed_ratio)
		
	var fov_weight = 1.0 - exp(-fov_change_speed * delta)
	camera.fov = lerp(camera.fov, target_fov, fov_weight)
